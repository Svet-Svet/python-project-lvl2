#!/usr/bin/env python
from gendiff.help import get_parsing
def main():
    get_parsing()

if __name__ == '__main__':
    main()